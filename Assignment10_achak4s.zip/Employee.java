package test;

public class Employee{
    
    private String firstName, lastName, fullName, review;
    private Date hired, fired;
    private int daysLeft, daysUsed;
    
    public Employee(){
        firstName = "";
        lastName = "";
        fullName = "";
        review =  "";
        hired = new Date();
        fired = new Date();
        daysLeft = 0;
        daysUsed = 0;
    }
    
    public Employee(String first, String last, String rev, Date hire, Date fire, int left, int used){
        firstName = first;
        lastName = last;
        fullName = (first + last);
        review =  rev;
        hired = hire;
        fired = fire;
        daysLeft = left;
        daysUsed = used;
    }
    
    public void setName(String first, String last){
        firstName = first;
        lastName = last;
        fullName = (first + last);
    }
    
    public String getName(){
        return fullName;
    }
    
    public void terminateEmployee(Date fire){
        fired = fire;
    }
    
    public Date getTerminationDate(){
        return fired;
    }
    
    public void SetHiredDate(Date hire){
        hired = hire;
    }
    
    public Date getHiredDate(){
        return hired;
    }
    
    public void setVacationDaysLeft(int left){
        daysLeft = left;
    }
    
    public int getVacationDaysLeft(){
        return daysLeft;
    }
    
    public void setVacationsScheduled(int used){
        daysUsed = used;
    }
    
    public int getVacationsScheduled(){
        return daysUsed;
    }
    
    public void setLastReview(String rev){
        review = rev;
    }
    
    public String getLastReview(){
        return review;
    }
    
    public void scheduleVacationDay(){
        daysLeft--;
        daysUsed++;
    }
    
    public void cancelVacationDay(){
        daysLeft++;
        daysUsed--;
    }
    
    public String toString(){
        return("Details on " + fullName + ":\n" + "Date Hired: " + hired.getDate() + "\nDate of Termination: " + fired.getDate() + "\nVacation Days Left: " + daysLeft + "\nVacation Days Scheduled: " + daysUsed + "\nLast Annual Review: " + review); 
    }
}
