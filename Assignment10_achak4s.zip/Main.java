package test;

import java.util.*;
import java.time.LocalDate;

public class Main
{
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<Employee> employeeList = new ArrayList<Employee>();
        Date terminationDate;
        
        for (int i = 0; i < 3; i++){
            System.out.println("Enter the Employee's First Name: ");
            String firstName = scan.nextLine();
            System.out.println("Enter the Employee's Last Name: ");
            String lastName = scan.nextLine();
            System.out.print("Enter the Employee's Last Annual Review: ");
            String lastReview = scan.nextLine();
            System.out.println("Enter the Employee's Day of Hire: ");
            int day = scan.nextInt();
            System.out.println("Enter the Employee's Month of Hire: ");
            int month = scan.nextInt();
            System.out.println("Enter the Employee's Year of Hire: ");
            int year = scan.nextInt();
            Date hireDate = new Date(day, month, year);
            System.out.println("Enter Employee's Day of Termination(Put 0 if N/A):");
            int day2 = scan.nextInt();
            System.out.println("Enter the Employee's Month of Termination(Put 0 if N/A): ");
            int month2 = scan.nextInt();
            System.out.println("Enter the Employee's Year of Termination(Put 0 if N/A): ");
            int year2 = scan.nextInt();
            terminationDate = new Date(day2, month2, year2);
            System.out.println("Enter the Employee's Remaining Vacation Days: ");
            int daysLeft = scan.nextInt();
            System.out.println("Enter the Employee's Scheduled Vacation Days: ");
            int daysUsed = scan.nextInt();
            
            Employee e = new Employee(firstName, lastName, lastReview, hireDate, terminationDate, daysLeft, daysUsed);
            
            employeeList.add(e);
            employeeList.get(i).scheduleVacationDay();
            employeeList.get(i).scheduleVacationDay();
            employeeList.get(i).cancelVacationDay();

        }
        
        employeeList.get(2).terminateEmployee(new Date(3,22,2023));
        
        for (Employee e : employeeList){
            System.out.println(e.toString());
        }
    }
}
