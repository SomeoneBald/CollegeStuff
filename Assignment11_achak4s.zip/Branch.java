package branchwork;

import java.util.ArrayList;

public class Branch {

	
	private int branchID;
	private String branchname, address;
	private ArrayList<Employee> team = new ArrayList<Employee>();
	private ArrayList<Manager> managers = new ArrayList<Manager>();
	
	public Branch() {
		branchID = 0;
		branchname = "";
		address = "";
	}
	
	public Branch(int id, String name, String add) {
		branchID = id;
		branchname = name;
		address = add;
	}
	
	public void setID(int id) {
		branchID = id;
	}
	
	public int getID() {
		return branchID;
	}
	
	public void setName(String name) {
		branchname = name;
	}
	
	public String getName() {
		return branchname;
	}
	
	public void setAddress(String adr) {
		address = adr;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void addManager(Manager supervisor) {
		managers.add(supervisor);
	}
	
	public void getManagers() {
		System.out.println("Mangers: ");
		for (Manager m : managers) {
			System.out.println(m.getManagerName());
		}
	}
	
	public void addEmployee(Employee e) {
		team.add(e);
	}
	
	public void removeEmployee(Employee e) {
		team.remove(e);
	}
	
	public void displayInfo() {
		System.out.println("Managers: ");
		for (Manager m : managers) {
			System.out.println(m.getManagerName());
		}
		System.out.println("Employees: ");
		for (Employee e : team) {
			System.out.println(e.toString());
		}
	}
}
