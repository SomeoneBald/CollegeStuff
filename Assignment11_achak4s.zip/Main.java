package branchwork;

import java.util.*;
import java.time.LocalDate;

public class Main
{
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<Employee> employeeList = new ArrayList<Employee>();
        ArrayList<Manager> managerList = new ArrayList<Manager>();
        //Date terminationDate;
        
        Date today = new Date( 7, 9, 2020);
        Employee e1 = new Employee("Bingus", "Lingus", "Stellar", today, new Date() , 0, 0, 1111);
        Employee e2 = new Employee("John", "Doe", "Hard worker, acts aloof", today, new Date() , 0, 0, 2222);
        Employee e3 = new Employee("Marnke", "Wakit", "Focused", today, new Date() , 0, 0, 3333);
        Employee e4 = new Employee("Oolgo", "Humite", "Friendly with others", today, new Date() , 0, 0, 4444);
        Employee e5 = new Employee("May", "Fekes", "Cooperative and understanding", today, new Date() , 0, 0, 5555);
        Employee e6 = new Employee("Bing", "Chilling", "Spends too much time in the break room", today, new Date() , 0, 0, 6666);
        Employee e7 = new Employee("Baurn", "Hoklan", "Forgets things often", today, new Date() , 0, 0, 7777);
        Employee e8 = new Employee("Gaara", "Sand", "Sandy", today, new Date() , 0, 0, 8888);
        Employee e9 = new Employee("Kaka", "Shi", "Very handy with the copy machine", today, new Date() , 0, 0, 1383);
        Employee[] employeeArray = {e1, e2, e3, e4, e5, e6, e7, e8, e9};
        
        Manager m1 = new Manager("Juan", "Gajarvis", 9912);
        Manager m2 = new Manager("Viktor", "Chuzev", 9945);
        Manager m3 = new Manager("Bobby", "Fischer", 9923);
        Manager[] managerArray = {m1, m2, m3};
        
        Branch b1 = new Branch(1000, "Baltimore", "100 Maryland Road");
        Branch b2 = new Branch(2000, "Boston", "293 Patriot Avenue");
        Branch b3 = new Branch(3000, "New York", "7172 Phillips Avenue");
        Branch[] branchArray = {b1, b2, b3};
        
        Branch selectedBranch = new Branch();
        boolean flag = true;
        while (flag) {
        	System.out.println("Would you Like to View a Cumulative Report[1], One for a Specified Branch[2], or Exit[3]?");
        	int temp = scan.nextInt();
        	if (temp == 1) {
        		for (Branch b : branchArray) {
        			System.out.println(b.getName() + " Branch: ");
        			b.displayInfo();
        		}
        	}
        	else if (temp == 2) {
        		System.out.println("Enter the branch ID below.");
            	int temp2 = scan.nextInt();
            	for (Branch b : branchArray) {
            		if (temp2 == b.getID()) {
            			selectedBranch = b;
            			boolean flag2 = true;
            			while (flag2) {
                    		System.out.println("Type 1 to assign a Manager\nType 2 to add an Employee\nType 3 to remove an Employee\nType 4 to View selected branch info\nType 5 to return");
                    		int choice = scan.nextInt();
                			if (choice == 1) {
                    			System.out.println("Enter Manager ID: ");
                    			int tempID = scan.nextInt();
                    			for (Manager m : managerArray) {
                    				if (tempID == m.getID())
                    					selectedBranch.addManager(m);        				
                    			}
                    			
                    		}
                    		else if (choice == 2) {
                    			System.out.println("Enter Employee ID: ");
                    			int tempID = scan.nextInt();
                    			for (Employee e : employeeArray) {
                    				if (e.getID() == tempID)
                    					selectedBranch.addEmployee(e);
                    			}
                    		}
                    		else if (choice == 3) {
                    			System.out.println("Enter Employee ID: ");
                    			int tempID = scan.nextInt();
                    			for (Employee e : employeeArray) {
                    				if (e.getID() == tempID)
                    					selectedBranch.removeEmployee(e);
                    		}
                    	}
                    		else if (choice ==4) {
                    			selectedBranch.displayInfo();
                    		}
                			
                    		else if (choice == 5) {
                    			temp = 0;
                    			flag2 = false;
                    		}
                    		else
                    			System.out.println("Please Enter a Valid Option");
                    	}
            		}
            	}
        	}
        	else if (temp == 3) {
        		flag = false;
        	}
        	else {
        		System.out.println("Please Input a Valid Option");
        	}
        }
    }
}
