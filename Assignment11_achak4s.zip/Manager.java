package branchwork;

public class Manager {

	private String firstname, lastname, fullname;
	private int managerID;
	
	public Manager() {
		firstname = "";
		lastname = "";
		fullname = "";
		managerID = 9999;
	}
	
	public Manager(String first, String last, int managID) {
		firstname = first;
		lastname = last;
		fullname = (first + " " + last);
		managerID = managID;
	}
	
	public void managerName(String first, String last) {
		 firstname = first;
	     lastname = last;
	     fullname = (first + last);
	}
	
	public String getManagerName() {
		return fullname;
	}
	
	public void setName(String name) {
		fullname = name;
	}
	
	public int getID() {
		return managerID;
	}
	
	public void setID(int id) {
		managerID = id;
	}
	
	
}
