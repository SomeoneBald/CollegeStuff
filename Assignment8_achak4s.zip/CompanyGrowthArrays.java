package Assignment8;

import java.util.Scanner;


public class CompanyGrowthArrays {

	private static int NumberOfIDs;
	private static int status;
	
static Scanner scanner = new Scanner(System.in);



	public static void main(String[] args) {
	Scanner scan = new Scanner(System.in);
		
		System.out.println("Welcome! This program will help you manage your employees' IDs and their employment status.");
		System.out.println("First, enter how many employee IDs you want to store. This should be a normal integer value.");

		int NumberID = scanner.nextInt();
		NumberOfIDs = NumberID;
		
		
		System.out.println("Number of IDs is: " + NumberOfIDs);
		
		System.out.println("Now enter your employee IDs. They should be 6 digits in length and only contain numbers.");
		
		int IDArray[] = new int [NumberOfIDs];
		for (int i = 0; i < IDArray.length; i++) {
			
			IDArray[i] = scanner.nextInt();
			
		}
		
		System.out.println("Here are your Employee IDs:");
		
		Sorting(IDArray);
		display(IDArray);
		employee(IDArray);
		
		// int [][] fulldisplay = new int [NumberOfIDs][2];
		
		// for (int i = 0; i < NumberOfIDs; i++) {
		// 	for (int j = 0; j <= 2; j++) {
		// 		System.out.print(fulldisplay[i][j] + "\t");
		// 	}
		// 	System.out.println();
		// }
			
		
	}

	public static void Sorting(int IDArray[]) {
		int currentMin = 0;
		int currentMinIndex = 0;
		for (int i = 0; i < IDArray.length - 1; i++) {
		
			currentMin = IDArray[i];
			currentMinIndex = i;
			
			for (int j = i + 1; j < IDArray.length; j++) {				
			if (currentMin > IDArray[j]) {
				currentMin = IDArray[j];
				currentMinIndex = j;
				}	
			}
			
			if (currentMinIndex != i) {
				IDArray[currentMinIndex] = IDArray[i];
				IDArray[i] = currentMin;
			}	
		}		
	}
	
	public static void display(int IDArray[]) {
        for (int j = 0; j < IDArray.length; j++) {
            System.out.print(IDArray[j] + " ");
        }
        System.out.println();
    }	
	
	static void employee(int IDArray[]) {
		System.out.println("Now, enter the employment status of each employee. This will correspond with the employee IDs stated above. Enter 1 for Hourly and 2 for Salaried Employment status.");


		
		int status[] = new int [NumberOfIDs];		
		for (int i = 0; i < NumberOfIDs; i++) {			
			status[i] = scanner.nextInt();
		}
		
		System.out.println("This is the employment status of each employee:");
		
		// for (int i = 0; i < status.length; i++) {
        //     System.out.print(status[i] + " ");
        // }
		// System.out.println("");
		
		int fulldisplay[][] = new int[NumberOfIDs][2];
		
		for (int i = 0; i < fulldisplay.length; i++) {
			fulldisplay[i][0] = IDArray[i];
		}

		for (int i = 0; i < fulldisplay.length; i++) {
			fulldisplay[i][1] = status[i];
		}

		for (int i = 0; i < NumberOfIDs; i++) {
			for (int j = 0; j < 2; j++) {
				System.out.print(fulldisplay[i][j] + "\t");
			}
			System.out.println();
		}
			
	}
	
	
}