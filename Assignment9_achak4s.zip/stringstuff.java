package stringwork;

//import java.util.Arrays;   <-- Was used in experimental idea
import java.util.Scanner;

public class stringstuff {
	
	public static String location1;
	public static String location2;
	public static String location3;
	public static String location4;
	public static int d1;
	public static int d2;
	public static int d3;
	public static int d4;
	static StringBuilder first = new StringBuilder();
	static StringBuilder second = new StringBuilder();
	static StringBuilder third = new StringBuilder();
	static StringBuilder fourth = new StringBuilder();
			
public static Scanner scanner = new Scanner(System.in);


	public static void main(String[] args) {
		System.out.println("Dear CEO, we've been discussing plans and we've realized that new offices should be opened up to support our company's growing employee number.");
		System.out.println("Please type in four locations that would be a great fit for a new office.");
		
		locations();
		distances();
		stringwork();
}
	public static void locations() {
		location1 = scanner.nextLine();
		location2 = scanner.nextLine();
		location3 = scanner.nextLine();
		location4 = scanner.nextLine();
		
		first.append(location1);
		second.append(location2);
		third.append(location3);
		fourth.append(location4);
		
		if (first.length() > 16) {
			System.out.println("This location is not valid, and is too long. Enter a shorter location name (preferably less than 16 characters in length.");
			first.delete(0, 0);
			location1 = scanner.nextLine();
			first.append(location1);
			System.out.println(location1);
	}
	    else if (second.length() > 16) {
			System.out.println("This value is not valid, and is too long. Enter a shorter location name (preferably less than 16 characters in length.");
			location2 = scanner.nextLine();
			second.append(location2);

	}
	    else if (third.length() > 16) {
			System.out.println("This value is not valid, and is too long. Enter a shorter location name (preferably less than 16 characters in length.");
			location3 = scanner.nextLine();

	}
	    else if (fourth.length() > 16) {
			System.out.println("This value is not valid, and is too long. Enter a shorter location name (preferably less than 16 characters in length.");
			location4 = scanner.nextLine();

	}
	}
	public static void distances() {
		System.out.println("Now, enter the distances for each location from our current headquarters.");
		
		d1 = scanner.nextInt();
		if (d1 > 800 || d1 < 100) {
			System.out.println("This location either is too far or too close to our headquarters to make an impact on our company. Re-enter a new distance/or new location.");
			d1 = scanner.nextInt();
		}
		d2 = scanner.nextInt();
		if (d2 > 800 || d2 < 100) {
			System.out.println("This location either is too far or too close to our headquarters to make an impact on our company. Re-enter a new distance/or new location.");
			d2 = scanner.nextInt();
		}
		d3 = scanner.nextInt();
		if (d3 > 800 || d3 < 100) {
			System.out.println("This location either is too far or too close to our headquarters to make an impact on our company. Re-enter a new distance/or new location.");
			d3 = scanner.nextInt();
		}
		d4 = scanner.nextInt();
		if (d4 > 800 || d4 < 100) {
			System.out.println("This location either is too far or too close to our headquarters to make an impact on our company. Re-enter a new distance/or new location.");
			d4 = scanner.nextInt();
		}
		
		
		
	}

	public static void stringwork() {
		System.out.println("Here is the final information provided:");
		
		System.out.println("Location: " + first + ", Distance: " + d1);
		System.out.println("Location: " + second + ", Distance: " + d2);
		System.out.println("Location: " + third + ", Distance: " + d3);
		System.out.println("Location: " + fourth + ", Distance: " + d4);
	}
}