package theend;

public class DatabasePermits {
	
	private String name;
	private double price;
public static int amount;
	

	public DatabasePermits() {
		name = "";
		price = 0.0;
		amount++;
	}

	public DatabasePermits(String n, double cost, int numb) {
		name = n;
		price = cost;
		amount = numb;
	}
	
	public void setName(String n) {
		name = n;
	}
	
	public String getName() {
		return name;
	}
	
	public void setPrice(double cost) {
		price = cost;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setAmount(int numb) {
		amount = numb;
	}
	
	public int getAmount() {
		return amount;
	}
	
	public String toString() {
		return("Name of Object: " + name + "\nPrice of Object: " + price + "\nAmount in Stock: " + amount); 
	}
	
	
	
}
