package theend;

import java.util.*;

import java.time.LocalDate;


public class Main {

	static Scanner scan = new Scanner(System.in);
	static DatabasePermits Dp = new DatabasePermits("Database Access Permit", 250.99, 212);
	static AsteroidInfo Ai = new AsteroidInfo("Asteroid Info Packages", 300.99, 18);
	static PhotoPermits Pp = new PhotoPermits("Photo Access Permits", 45.99, 300);
	
	public static void main(String[] args) {
		
		System.out.println("Welcome to Frontier's Business Management system.");
		System.out.println("Select 1 to enter the Inventory actions menu, 2 to enter the Sales actions menu, and 3 to exit the program.");
		int choice = scan.nextInt();

		if (choice == 1) {
			inventoryActions();
		}
		
		else if (choice == 2) {
			salesActions();
		}
		
		else if (choice == 3) {
			System.out.println("Goodbye!");
			exit();
		}

		else {
			System.out.println("Please enter a valid input.");
			main(null);
		}
	}
	
	public static void inventoryActions() {
		System.out.println("Welcome to the inventory actions menu, what would you like to do?\n1. Add a product to the system\n2. View inventory\n3. Modify a product's properties\n4. Return to main menu");
		int choice = scan.nextInt();
		if (choice == 1) {
			System.out.println("Which product would you like to add?\n1. Database Permits\n2. Asteroid Info Packages\n3. Photo Permits\n4. Exit to main menu");
			int choice1 = scan.nextInt();
			if (choice1 == 1) {
				System.out.println("How many would you like to add to the inventory?");
				int added = scan.nextInt();
				Dp.setAmount(Dp.getAmount() + added);
				System.out.println("There are now " + Dp.getAmount() + " Data permits in the inventory.");
				inventoryActions();
			}
		
			else if (choice1 == 2) {
				System.out.println("How many would you like to add to the inventory?");
				int added = scan.nextInt();
				Ai.setAmount(Ai.getAmount() + added);
				System.out.println("There are now " + Ai.getAmount() + " Asteroid info packages in the inventory.");
				inventoryActions();
			}
			
			else if (choice1 == 3) {
				System.out.println("How many would you like to add to the inventory?");
				int added = scan.nextInt();
				Pp.setAmount(Pp.getAmount() + added);
				System.out.println("There are now " + Pp.getAmount() + " Asteroid info packages in the inventory.");
				inventoryActions();
			}

			else if (choice1 ==4){
				main(null);
			}
			
			else {
				System.out.println("Please Enter a Valid Input");
				inventoryActions();
			}
			
		}
		
		else if (choice == 2) {
			System.out.println("These are the current items in the inventory: ");
			System.out.println("Database permits: " + Dp.getAmount());
			System.out.println("Asteroid info packages: " + Ai.getAmount());
			System.out.println("Photo permits " + Pp.getAmount());
			inventoryActions();
		}
		
		else if (choice == 3) {
			System.out.println("Which product would you like to change the characteristics of?\n1. Database permits\n2. Asteroid info packages\n3. Photo permits\n4. Return");
			int choice1 = scan.nextInt();
			if (choice1 == 1) {
				System.out.println("Would you like to change the 1. price or 2. name of the product?");
				int i = scan.nextInt();
				if (i == 2) {
					System.out.println("What would you like the new name to be?");
					String newname = scan.nextLine();
					Dp.setName(newname);
					inventoryActions();
				}
				else if (i == 1){
					System.out.println("What would you like the new price to be?");
					Double newprice = scan.nextDouble();
					Dp.setPrice(newprice);
					System.out.println("The new price is: " + Dp.getPrice());
					inventoryActions();
				}
				else {
					System.out.println("Enter a valid input.");
					inventoryActions();
				}
					
			}
		
			else if (choice1 == 2) {
				System.out.println("Would you like to change the 1. price or 2. name of the product?");
				int i = scan.nextInt();
				if (i == 2) {
					System.out.println("What would you like the new name to be?");
					String newname = scan.nextLine();
					Ai.setName(newname);
					inventoryActions();
					
				}
				else if (i == 1){
					System.out.println("What would you like the new price to be?");
					Double newprice = scan.nextDouble();
					Ai.setPrice(newprice);
					System.out.println("The new price is: " + Ai.getPrice());
					inventoryActions();

				}
				else {
					System.out.println("Enter a valid input.");
					inventoryActions();
				}
			}
			
			else if (choice1 == 3) {
				System.out.println("Would you like to change the 1. price or 2. name of the product?");
				int i = scan.nextInt();
				if (i == 2) {
					System.out.println("What would you like the new name to be?");
					String newname = scan.nextLine();
					Pp.setName(newname);
					inventoryActions();
				}
				else if (i == 1){
					System.out.println("What would you like the new price to be?");
					Double newprice = scan.nextDouble();
					Pp.setPrice(newprice);
					System.out.println("The new price is: " + Pp.getPrice());
					inventoryActions();
				}
				else {
					System.out.println("Enter a valid input.");
					inventoryActions();
				}
			}

			else if (choice1 == 4){
				inventoryActions();
			}
			else {
				System.out.println("Please enter a valid input");
				inventoryActions();
			}
			
		}
			
		else if (choice == 4){
			main(null);
		}
	}
	
	public static void salesActions() {
		System.out.println("Welcome to the sales actions menu, what would you like to do?\n1. View products and their properties\n2. Buy products\n3. Return products\n4. Return to main menu");
		int choice = scan.nextInt();
		if (choice == 1) {
			System.out.println(Dp.toString() + "\n----------------------------------------\n" + Ai.toString() + "\n----------------------------------------\n" + Pp.toString() );
			salesActions();
		}
		
		else if (choice == 2) {
			System.out.println("Which product would you like to buy?\n1. Database Permits\n2. Asteroid Info Packages\n3. Photo Permits\n4. Exit to main menu");
			int choice1 = scan.nextInt();
			if (choice1 == 1) {
				System.out.println("How many would you like to buy?");
				int sold = scan.nextInt();
				Dp.setAmount(Dp.getAmount() - sold);
				System.out.println("Your total is: " + (Dp.getPrice()*sold));
				System.out.println("There are now " + Dp.getAmount() + " Data permits in stock.");
				salesActions();
			}
		
			else if (choice1 == 2) {
				System.out.println("How many would you like to buy?");
				int sold = scan.nextInt();
				Ai.setAmount(Ai.getAmount() - sold);
				System.out.println("Your total is: " + (Ai.getPrice()*sold));
				System.out.println("There are now " + Ai.getAmount() + " Asteroid info packages in stock.");
				salesActions();
			}
			
			else if (choice1 == 3) {
				System.out.println("How many would you like to buy?");
				int sold = scan.nextInt();
				Pp.setAmount(Pp.getAmount() - sold);
				System.out.println("Your total is: " + (Pp.getPrice()*sold));
				System.out.println("There are now " + Dp.getAmount() + " Photo permits in stock.");
				salesActions();
			}

			else if (choice1 ==4){
				main(null);
			}
		}
		
		else if (choice == 3) {
			System.out.println("Which product would you like to return?\n1. Database Permits\n2. Asteroid Info Packages\n3. Photo Permits\n4. Exit to main menu");
			int choice1 = scan.nextInt();
			if (choice1 == 1) {
				System.out.println("How many would you like to return?");
				int returning = scan.nextInt();
				Dp.setAmount(Dp.getAmount() + returning);
				System.out.println("Your cashback is: " + (Dp.getPrice()*returning));
				System.out.println("There are now " + Dp.getAmount() + " Data permits in stock.");
				salesActions();
			}
		
			else if (choice1 == 2) {
				System.out.println("How many would you like to buy?");
				int returning = scan.nextInt();
				Ai.setAmount(Ai.getAmount() + returning);
				System.out.println("Your cashback is: " + (Ai.getPrice()*returning));
				System.out.println("There are now " + Ai.getAmount() + " Asteroid info packages in stock.");
				salesActions();
			}
			
			else if (choice1 == 3) {
				System.out.println("How many would you like to buy?");
				int returning = scan.nextInt();
				Pp.setAmount(Pp.getAmount() + returning);
				System.out.println("Your cashback is: " + (Pp.getPrice()*returning));
				System.out.println("There are now " + Dp.getAmount() + " Photo permits in stock.");
				salesActions();
			}

			else if (choice1 ==4){
				main(null);
			}
		}

		else {
			main(null);
		}
	}
	
	private static void exit() {
		
	}

}
