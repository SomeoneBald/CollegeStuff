package CompanyInfo;

public class CompanyInfo {

	public static void main(String[] args) {
		System.out.println("Frontier");
		System.out.println("CEO: Arun Chakka");
		System.out.println("Founding Date: 7/1/2021");
	}

}
