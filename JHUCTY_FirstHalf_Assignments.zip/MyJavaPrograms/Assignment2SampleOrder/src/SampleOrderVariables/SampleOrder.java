package SampleOrderVariables;

import java.util.Scanner;

public class SampleOrder {

	public static void main(String[] args) {
		Scanner myObj = new Scanner(System.in);
		
		System.out.println("How many months would you like to have access to our databanks?");
		int months = myObj.nextInt();
		
		int monthlyprice = 99;
		int price = monthlyprice*months;
	
		System.out.println("Your purchase of " + months + " month(s) access will cost " + price +  " dollars.");
	}

}
