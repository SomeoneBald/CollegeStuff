package LoanCalculation;

import java.util.Scanner;

public class Loan {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("How much money would you like to take a loan for?");
		int loanAmount = scanner.nextInt();
		
		System.out.println("How many years would you like to pay this loan back over?");
		int years = scanner.nextInt();
		int numberPeriods = years*12;
		
		System.out.println("What interest rate would you like to pay the bank back at?");
		double interestrate = scanner.nextDouble();
		double rate = interestrate/12/100;
		//double discount = ((Math.pow((1+rate),numberPeriods)-1))/(rate*Math.pow(1+rate,numberPeriods));
		double discount = ((Math.pow((1+rate),numberPeriods)-1))/(rate*Math.pow(1+rate, numberPeriods));
		
		System.out.println("Here are your details:");
		System.out.println("Loan Amount: " + loanAmount);
		System.out.println("Your interest rate: "+interestrate);
		System.out.println("Payment periods(montly):" + numberPeriods);
		System.out.println("Your periodic interest rate:" + rate);
		double monthlypayment = loanAmount/discount;
		System.out.println("Your monthly payment will be: "+monthlypayment);
		double totalpayment = (monthlypayment*numberPeriods);
		System.out.println("Your total payment will be: "+totalpayment);
		System.out.println(discount);
	}

}
