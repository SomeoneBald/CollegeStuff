package InvestorCalculation;

import java.util.Scanner;

public class InvestorCalc {

	public static void main(String[] args) {
		Scanner scanner  = new Scanner(System.in);
		
		System.out.println("What is the current value of the company?");
		int companyval = scanner.nextInt();
		
		System.out.println("How much money will be invested into the company?");
		int invamt = scanner.nextInt();
		
		System.out.println("What percentage of the company is the investor buying?");
		float invperc = scanner.nextFloat();
		
		System.out.println("How many years will the investor invest in the company?");
		int years = scanner.nextInt();
		
		System.out.println("What is the current growth rate for the company?");
		float growthrate = (scanner.nextFloat()/100);
		double companyFuturevalue = companyval*Math.pow(1+growthrate,years);
		double invfuturevalue = (invperc/100)*companyFuturevalue;
		
		System.out.println("The information you have provided is:");
		System.out.println("Current Company value: "+companyval);
		System.out.println("Money being invested: "+invamt);
		System.out.println("Percentage of company being bought: "+invperc);
		System.out.println("The number of years for the investment: "+years);
		System.out.println("Are you ready to continue?");
		char abc = scanner.next().charAt(0);
		
		System.out.printf("The company's future value will be: %.2f\n", +companyFuturevalue);
		double ownerFuturevalue = companyFuturevalue-(invamt+invfuturevalue);
		System.out.printf("The owner's future value is: %.2f\n", +ownerFuturevalue);
		System.out.printf("The investors future percentage is: %.2f\n", +invfuturevalue);
	}

}
