package inventorytrack;

import java.text.*;

import java.util.Scanner; 

public class companyinventory {

	public static void main(String[] args) {
		Scanner scanner  = new Scanner(System.in);
		DecimalFormat decFormat = new DecimalFormat("$#,###.00"); 
		
		System.out.println("What is your name?");
		char name = scanner.next().charAt(0);
		
		System.out.println("Alright "+name+", how many hours do you want to sign up for? These hours will allow you to access our photo databanks.");
		int hours = scanner.nextInt();
		double price = hours*35;
			if (hours == 10) {
			System.out.println("You have requested, "+hours+" hours. We can provide you with 10 hours of access. Your total cost is:");
			System.out.println(decFormat.format(price));
			}
			else if (hours > 10) {
				System.out.println("The number of hours requested, "+hours+", is above the contracted amount.");	
			}
			else if (hours < 10) {
				System.out.println("We are able to provide you with "+hours+" hours. Your total cost is:");
				System.out.println(decFormat.format(price));
				System.out.println("You now have "+(10-hours)+" hours remaining.");
			}
			
			
			
			
	}

}
