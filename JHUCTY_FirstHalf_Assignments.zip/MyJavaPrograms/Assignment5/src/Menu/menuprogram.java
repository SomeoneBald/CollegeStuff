package Menu;

import java.text.DecimalFormat;
import java.util.Scanner;

public class menuprogram {

	public static void main(String[] args) {
		Scanner scanner  = new Scanner(System.in);
		DecimalFormat decFormat = new DecimalFormat("$#,###.00"); 
		
		System.out.println("--------------------------------------------------------------------------------------------");
		System.out.println("--* * * * *   * * *      * * *    * *        *   * * * * * * *   *   * * * * *   * * *   -- ");
		System.out.println("--*           *    *    *     *   *  *       *         *         *   *           *    *  -- ");
		System.out.println("--*           *    *    *     *   *   *      *         *         *   *           *    *  -- ");
		System.out.println("--* * * *     * * *     *     *   *    *     *         *         *   * * * * *   * * *   -- ");
		System.out.println("--*           *   *     *     *   *     *    *         *         *   *           *   *   -- ");
		System.out.println("--*           *    *    *     *   *      *   *         *         *   *           *    *  -- ");
		System.out.println("--*           *     *   *     *   *       *  *         *         *   *           *     * -- ");
		System.out.println("--*           *      *   * * *    *        * *         *         *   * * * * *   *      *-- ");
		System.out.println("--------------------------------------------------------------------------------------------");
		
		
		System.out.println("Welcome to Frontier! We help provide information on new opportunities in outer space, and cater to both industry specialists, scientists, and civilians!");
		
		System.out.println("Here are some products we offer:");
		System.out.println("Database access - $200 per month");
		double daccess = 200;
		System.out.println("Photo access (recommended for scientists and civilians) - $20 a month");
		double paccess = 20;
		System.out.println("Information on resource rich asteroids (recommended for companies) - $100 per information package");
		double astinfo = 100;
		System.out.println("Near Earth Asteroid discoveries (recommended for scientists) - $50 per each asteroid");
		double NEAD = 50;
		
		
		//These variables below represent each item.
		
		double one = daccess;
		double two = paccess;
		double three = astinfo;
		double four = NEAD;
		boolean yn;
		
		outer:
		System.out.println("What item would you like to purchase? Please choose a number between 1-4.");
		int choice = scanner.nextInt();
		if (choice == 1) {
			System.out.println("How many months would you like access to the databanks?");
			int months1 = scanner.nextInt();
			double price1 = months1*one;
			System.out.println("That will cost "+price1+" dollars. Is there anything else you would like to purchase?");
			String yeno1 = scanner.next();
				
			switch(yeno1) {
			case "yes":
				yn = true;
				System.out.println("Here are some products we offer:");
				System.out.println("Database access - $200 per month");
				System.out.println("Photo access (recommended for scientists and civilians) - $20 a month");
				System.out.println("Information on resource rich asteroids (recommended for companies) - $100 per information package");
				System.out.println("Near Earth Asteroid discoveries (recommended for scientists) - $50 per each asteroid");
				break;
				
			case "no":
				yn = false;
				System.out.println("Your final amount comes out to $"+price1+". Have a good day!");
				break;
			}
		}
		
		if (choice == 2) {
			System.out.println("How many months would you like access to the photo databanks?");
			int months2 = scanner.nextInt();
			double price2 = months2*two;
			System.out.println("That will cost "+price2+" dollars. Is there anything else you would like to purchase?");
			String yeno2 = scanner.next();
			
			switch(yeno2) {
			case "yes":
				yn = true;
				System.out.println("Here are some products we offer:");
				System.out.println("Database access - $200 per month");
				System.out.println("Photo access (recommended for scientists and civilians) - $20 a month");
				System.out.println("Information on resource rich asteroids (recommended for companies) - $100 per information package");
				System.out.println("Near Earth Asteroid discoveries (recommended for scientists) - $50 per each asteroid");
				
			
			case "no":
				yn = false;
				System.out.println("Your final amount comes out to $"+price2+". Have a good day!");
				break;
			}

	}
		if (choice == 3) {
			System.out.println("How many packages would you like to purchase?");
			int packages3 = scanner.nextInt();
			double price3 = packages3*three;
			System.out.println("That will cost "+price3+" dollars. Is there anything else you would like to purchase?");
			String yeno3 = scanner.next();
			
			switch(yeno3) {
			case "yes":
				yn = true;
				System.out.println("Here are some products we offer:");
				System.out.println("Database access - $200 per month");
				System.out.println("Photo access (recommended for scientists and civilians) - $20 a month");
				System.out.println("Information on resource rich asteroids (recommended for companies) - $100 per information package");
				System.out.println("Near Earth Asteroid discoveries (recommended for scientists) - $50 per each asteroid");
				
			
			case "no":
				yn = false;
				System.out.println("Your final amount comes out to $"+price3+". Have a good day!");
				break;
			}

	}
		if (choice == 4) {
			System.out.println("How many packages would you like to purchase?");
			int asteroids4 = scanner.nextInt();
			double price4 = asteroids4*four;
			System.out.println("That will cost "+price4+" dollars. Is there anything else you would like to purchase?");
			String yeno4 = scanner.next();
			
			switch(yeno4) {
			case "yes":
				yn = true;
				System.out.println("Here are some products we offer:");
				System.out.println("Database access - $200 per month");
				System.out.println("Photo access (recommended for scientists and civilians) - $20 a month");
				System.out.println("Information on resource rich asteroids (recommended for companies) - $100 per information package");
				System.out.println("Near Earth Asteroid discoveries (recommended for scientists) - $50 per each asteroid");
				
			
			case "no":
				yn = false;
				System.out.println("Your final amount comes out to $"+price4+". Have a good day!");
				break;
			}

	}
		
}
}


