package testing;

import java.text.DecimalFormat;
import java.util.Scanner;

public class programtesting {

	public static void main(String[] args) {
		Scanner scanner  = new Scanner(System.in);
		DecimalFormat decFormat = new DecimalFormat("$#,###.00"); 
		
		
		
		System.out.println("--------------------------------------------------------------------------------------------");
		System.out.println("--* * * * *   * * *      * * *    * *        *   * * * * * * *   *   * * * * *   * * *   -- ");
		System.out.println("--*           *    *    *     *   *  *       *         *         *   *           *    *  -- ");
		System.out.println("--*           *    *    *     *   *   *      *         *         *   *           *    *  -- ");
		System.out.println("--* * * *     * * *     *     *   *    *     *         *         *   * * * * *   * * *   -- ");
		System.out.println("--*           *   *     *     *   *     *    *         *         *   *           *   *   -- ");
		System.out.println("--*           *    *    *     *   *      *   *         *         *   *           *    *  -- ");
		System.out.println("--*           *     *   *     *   *       *  *         *         *   *           *     * -- ");
		System.out.println("--*           *      *   * * *    *        * *         *         *   * * * * *   *      *-- ");
		System.out.println("--------------------------------------------------------------------------------------------");
		
		
		System.out.println("Welcome to Frontier! We help provide information on new opportunities in outer space, and cater to both industry specialists, scientists, and civilians!");
		
		System.out.println("Here are some products we offer:");
		System.out.println("Database access - $200 per month");
		double daccess = 200;
		System.out.println("Photo access (recommended for scientists and civilians) - $20 a month");
		double paccess = 20;
		System.out.println("Information on resource rich asteroids (recommended for companies) - $100 per information package");
		double astinfo = 100;
		System.out.println("Near Earth Asteroid discoveries (recommended for scientists) - $50 per each asteroid");
		double NEAD = 50;
		
		
		//These variables below represent each item.
		
		double one = daccess;
		double two = paccess;
		double three = astinfo;
		double four = NEAD;
		boolean yn;
		double finalprice = 0;
		int counter = 0;
		int counter1 = 0;
		outer:
		
		for (int i = 0; i < 2; i++) // counter 
		{
		
		System.out.println("What item would you like to purchase? Please choose a number between 1-4.");
		int choice = scanner.nextInt();
		
		
		if (choice == 1) {
			System.out.println("How many months would you like access to the databanks?");
			int months1 = scanner.nextInt();
			double price1 = months1*one;
			System.out.println("That will cost $"+price1+".");
			finalprice = finalprice + price1;
			counter = counter+1;
			counter1 = counter1+months1;
			}
		
		if (choice == 2) {
			System.out.println("How many months of photo access do you need?");
			int months2 = scanner.nextInt();
			double price2 = months2*two;
			System.out.println("Photo access will cost $"+price2+".");
			finalprice = finalprice + price2;
			counter = counter+1;
			counter1 = counter1+months2;
			}
		
		if (choice == 3) {
			System.out.println("How many packages would you like to purchase?");
			int packages3 = scanner.nextInt();
			double price3 = packages3*three;
			System.out.println("Those will cost $"+price3+".");
			finalprice = finalprice + price3;
			counter1 = counter1+packages3;
			}
		
		if (choice == 4) {
			System.out.println("How many asteroids would you like to get info for?");
			int asteroids4 = scanner.nextInt();
			double price4 = asteroids4*four;
			System.out.println("Those asteroids will cost $"+price4+".");
			finalprice = finalprice + price4;
			counter1 = counter1+asteroids4;
			}
		
		
		
	} //end outer
		if (counter1 > 10 && counter != 2) {
			System.out.println("Congrats, you've gained a 5% discount!");
			System.out.println("Your final price will be: $"+(finalprice*0.95)+".");
		}
		
		if (counter == 2 && counter1 >10) {
			System.out.println("You've gained 2 discounts of 5 and 10 percent each!");
			System.out.println("Your final price will be: $"+(finalprice*0.85));
		}
		if (counter == 2 && counter1 <= 10) {
			System.out.println("Congratulations, you've gained a 10% discount!");
			System.out.println("Your final price will be: $"+(finalprice*0.9)+".");
		}
		
		if (counter != 2 && counter1 <= 10) {
			System.out.println("Your final price will be: $"+finalprice+".");
		}
		
	}
}	
	
			

	
		

