package creditcards;

import java.text.DecimalFormat;
import java.util.Scanner;

public class PaymentProcessing {

	public static void main(String[] args) {
		Scanner scanner  = new Scanner(System.in);
		DecimalFormat decFormat = new DecimalFormat("$#,###.00"); 
		
		
		System.out.println("Please enter your payment option (credit): ");
		String choice = scanner.next();
		validcard();
		
		
		
		
		
		
		
	
	

		
}
	public static void getcreditcardinfo() {
		Scanner scanner  = new Scanner(System.in);
		DecimalFormat decFormat = new DecimalFormat("$#,###.00"); 
		System.out.println("Please put your card number in again for confirmation.");
		
		long cardnumber = scanner.nextLong();

		long firstnumber = cardnumber;
		
		long fin = cardnumber;
		
		while(firstnumber >= 10)
		{
			firstnumber = firstnumber/10;
			
		}
		int count = 0;
		
		while (cardnumber != 0) {
			cardnumber /= 10;
			++count;
		}
		
		if (firstnumber == 3) {
			if (count == 15) {
				System.out.println("Your card is from American Express.");	
				System.out.println("Summary: Your card number is "+fin+", and you are paying with credit.");
			}
			else {
				System.out.println("Your card is invalid. Please restart the process.");
				
			}
		}
			
		else if (firstnumber == 4) {
			if (count == 16) {
				System.out.println("Your card is from Visa.");
				System.out.println("Summary: Your card number is "+fin+", and you are paying with credit.");

			}
			else {
				System.out.println("Your card is invalid. Please restart the process.");
			}
		}
		
		else if (firstnumber == 5) {
			if (count == 16) {
				System.out.println("Your card is from Mastercard.");
				System.out.println("Summary: Your card number is "+fin+", and you are paying with credit.");

			}
			else {
				System.out.println("Your card is invalid. Please restart the process.");
			};
		}
		
		else if (firstnumber == 6) {
			if (count == 16) {
				System.out.println("Your card is from Discover.");
				System.out.println("Summary: Your card number is "+fin+", and you are paying with credit.");

			}
			else {
				System.out.println("Your card is invalid. Please restart the process.");
			}
		}
		
		}
		
		
	public static void validcard() {
		Scanner scanner  = new Scanner(System.in);
		DecimalFormat decFormat = new DecimalFormat("$#,###.00"); 
		System.out.println("Please enter your credit card number.");
		long cardnumber = scanner.nextLong();
		
		int count = 0;
		
		while (cardnumber != 0) {
			cardnumber /= 10;
			++count;
		}
			if (count == 15) {
			getcreditcardinfo();
			}
			else if (count == 16) {
			getcreditcardinfo();
			}
			else  {
			System.out.println("Your credit card number is invalid/incorrect.");
			System.out.println("Would you like to use a different payment system instead? (money or a purchase requisition, please type yes or no)");
			String answer = scanner.next();
				
				if (answer.equals("yes")) {
					System.out.println("Would you like to use money, or a purchase requisition (pr)?");
					String answer1= scanner.next();
					
					if (answer1.equals("money")) {
						System.out.println("Head to our nearest location to complete the purchase by talking to an employee.");
						System.exit(0);
					}
					else if (answer1.equals("pr")) {
						System.out.println("Head to our nearest location to complete the purchase by talking to an employee.");
						System.exit(0);
					}
			}
				else if (answer.equals("no")) {
					validcard();
				}
		}
	}
}


