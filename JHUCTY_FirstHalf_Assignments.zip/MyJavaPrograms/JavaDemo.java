public class JavaDemo {
	public static void main(String [] args) {
		System.out.println( "Today is a great day for Java programming" );
		System.out.println( "It most certainly is!!" );
	}
}