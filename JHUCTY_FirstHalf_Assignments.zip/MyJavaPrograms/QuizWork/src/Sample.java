import java.util.*;

public class Sample {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter 2 numbers:");
		int first = input.nextInt();
		int second = input.nextInt();
		step1(first, second);
	}

	public static void step1(int a, int b){
		double result = step2(a, b);
		//System.out.println(a + " / " + b + " = " + result);
		System.out.println(a + " / " + b + " = " + result);
	}

	public static double step2(int a, int b){
		return a/b;
	}
}
