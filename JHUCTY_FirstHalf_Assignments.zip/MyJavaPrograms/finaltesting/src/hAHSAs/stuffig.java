package hAHSAs;

import java.util.Scanner;

public class stuffig {

	public static void main(String[] args) {
		
		int i = 3;
		
		do {
			System.out.println("*");
			i++;
		} while(i<9);
		
		
		
		}
	}