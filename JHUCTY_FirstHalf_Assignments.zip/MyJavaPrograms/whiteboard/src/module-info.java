module whiteboard {
}