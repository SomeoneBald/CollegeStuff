package whiteboardstuff;
import java.text.DecimalFormat;
import java.util.Scanner;


public class Workspacestuff {

	public static void main(String[] args) {
		//Scanner scanner  = new Scanner(System.in);
		//System.out.println("I'm here. ");
		//for (int i = 0; i < 30; i++) {	
		//	System.out.println("out    ");
		//String yeno = scanner.next();
		//	if(i>20) {
		//System.out.println("I'm here. "+i);
		//if (yeno == "yes") {
		//System.out.println("I'm here. "+i);
		//}
		//	}	
	//}
		
		Scanner scanner  = new Scanner(System.in);
		DecimalFormat decFormat = new DecimalFormat("$#,###.00"); 
		
		
		
		System.out.println("Welcome, this program will help you setup dates when we can ship your purchases to you.");
		
		

		System.out.println("Here are some products we offer:");
		System.out.println("Database access - $200 per month");
		double daccess = 200;
		System.out.println("Photo access (recommended for scientists and civilians) - $20 a month");
		double paccess = 20;
		System.out.println("Information on resource rich asteroids (recommended for companies) - $100 per information package");
		double astinfo = 100;
		System.out.println("Near Earth Asteroid discoveries (recommended for scientists) - $50 per each asteroid");
		double NEAD = 50;
		
		//these were in my assignment 5 program
		
		double one = daccess;
		double two = paccess;
		double three = astinfo;
		double four = NEAD;
		boolean yn;
		String mon[]={"January", "February", "March","April", "May", "June", "July", "August", "September", "October", "November", "December"};
	
		
		for (int i = 0; i < 3; i++)
		{
			
			
			
			System.out.println("Would you like to continue with another order?");
			
			
			
			String yeno2=scanner.next();

			switch(yeno2) {
			case "yes":

			
			System.out.println("Please select a product from the options below. Enter a number 1-4 to choose the product.");
			int choice = scanner.nextInt();
			
				if (choice == 1) {
				System.out.println("Please say what month you'd like the product to be shipped to you, select a number between 1-12.");
				int month = scanner.nextInt();
				System.out.println("What day would you like it shipped to you?");
				int day = scanner.nextInt();
					if (day > 31 || day < 1) {
					System.out.println("Please put in a valid day.");
					}
					else {
						System.out.println("Please enter what year you'd like the product to be shipped/sent to you.");
						int year = scanner.nextInt();
						if (blockOutDay(month,day)) {

					          System.out.print("We regret this date is unavailable. ");
						}
						else {
							System.out.println("Your shipment date is now: "+mon[month-1]+" "+day+","+year+".");
					}
				}
				}
				else if (choice == 2) {
				System.out.println("Please say what month you'd like the product to be shipped to you, select a number between 1-12.");
				int month2 = scanner.nextInt();
				System.out.println("What day would you like it shipped to you?");
				int day2 = scanner.nextInt();
					if (day2> 31) {
					System.out.println("Please put in a valid day.");
						}
					else {
						System.out.println("Please enter what year you'd like the product to be shipped/sent to you.");
						int year2= scanner.nextInt();
						if (blockOutDay(month2,day2)) {

					          System.out.print("We regret this date is unavailable. ");
						}
						else {
							System.out.println("Your shipment date is now: "+mon[month2-1]+" "+day2+","+year2+".");
					}
					}
				}
				else if (choice == 3) {
				System.out.println("Please say what month you'd like the product to be shipped to you, select a number between 1-12.");
				int month3 = scanner.nextInt();
				System.out.println("What day would you like it shipped to you?");
				int day3 = scanner.nextInt();
					if (day3> 31) {
					System.out.println("Please put in a valid day.");
						}
					else {
						System.out.println("Please enter what year you'd like the product to be shipped/sent to you.");
						int year3= scanner.nextInt();
						if (blockOutDay(month3,day3)) {

					          System.out.print("We regret this date is unavailable. ");
						}
						else {
							System.out.println("Your shipment date is now: "+mon[month3-1]+" "+day3+","+year3+".");
					}
					}
				}
				else if (choice == 4) {
					System.out.println("Please say what month you'd like the product to be shipped to you, select a number between 1-12.");
					int month4 = scanner.nextInt();
					System.out.println("What day would you like it shipped to you?");
					int day4 = scanner.nextInt();
						if (day4> 31) {
						System.out.println("Please put in a valid day.");
							}
						else {
							System.out.println("Please enter what year you'd like the product to be shipped/sent to you.");
							int year4= scanner.nextInt();
							if (blockOutDay(month4,day4)) {

						          System.out.print("We regret this date is unavailable. ");
							}
							else {
								System.out.println("Your shipment date is now: "+mon[month4-1]+" "+day4+","+year4+".");
						}
						}
					}
		}
		switch(yeno2) {
		case "no":
			System.out.println("THANK YOU FOR ORDERING WITH US.  WE LOOK FORWARD TO SEEING YOU AGAIN SOON");
			System.out.println("                 BYE                 ");
			System.exit(i);
		}
}
}
	public static int getStartDay( int m, int d, int y )

	   {

	      // Adjust month number & year to fit Zeller's numbering system

	      if ( m < 3 )

	      {

	         m = m + 12;

	         y = y - 1;

	      }

	  

	      int k = y % 100;      // Calculate year within century

	      int j = y / 100;      // Calculate century term

	      int h = 0;            // Day number of first day in month 'm'

	  

	      h = ( d + ( 13 * ( m + 1 ) / 5 ) + k + ( k / 4 ) + ( j / 4 ) + ( 5 * j ) ) % 7;

	  

	      // Convert Zeller's value to ISO value (1 = Mon, ... , 7 = Sun )

	      int dayNum = ( ( h + 5 ) % 7 ) + 1;    

	   

	      return dayNum;

	   }
		
	 public static boolean blockOutDay(int month, int day){

		    return (month == 1 && day == 1) || (month == 3 && day == 20) || (month == 4 && day == 22) || (month == 5 && day == 1) || (month == 6 && day == 5) || (month == 8 && day == 2) || (month == 12 && day == 31);

		  }
}

	
