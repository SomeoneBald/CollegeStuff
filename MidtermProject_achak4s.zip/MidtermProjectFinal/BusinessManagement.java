package business;

import java.util.Scanner;

public class BusinessManagement {

	static Scanner scanner = new Scanner(System.in);
	private static int daccessamt;
	private static int paccessamt;
	private static int astinfoamt;
	private static int NEADamt;
	

	public static void main(String[] args) {
		System.out.println("Welcome to Frontier's management system, what would you like to see?");
		System.out.println("1. Inventory Actions");
		int inventoryactions = 1;
		System.out.println("2. Sales Actions");
		int salesactions = 2;
		System.out.println("3. Exit Program");
		int exit = 3;
		

		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Type in the corresponding number to access each menu. (1,2,3 etc.)");
		int selectionuno = scanner.nextInt();
		if (selectionuno == 1) {
			inventoryactions();
		}
		else if (selectionuno == 2 ) {
			salesactions();
		}
		else if (selectionuno == 3) {
			System.out.println("Goodbye!");
			System.exit(0);
		}
		}
		
		
	
	 static void inventoryactions() {
		System.out.println("Welcome to the Inventory menu, what would you like to do?");
		System.out.println("1. Add a product to the inventory");
		System.out.println("2. View inventory");
		System.out.println("3. Exit to Main Menu");
		int selectiontwo = scanner.nextInt();
		


		if (selectiontwo == 1) {
			
			System.out.println("What would you like to add to the inventory? Numbers are 1-4 corresponding with each product.");
			System.out.println("Database access permits - $200 per month");
			System.out.println("Photo access permits (recommended for scientists and civilians) - $20 a month");
			System.out.println("Information on resource rich asteroids  (recommended for companies) - $100 per information package");
			System.out.println("Near Earth Asteroid discoveries (recommended for scientists) - $50 per each asteroid");
			
			//these are from my previous assignments
			
			int productselection = scanner.nextInt();
			
			if (productselection == 1) {
				System.out.println("How many database access permits would you like to add?");
				int amountadded1 = scanner.nextInt();
				daccessamt = amountadded1 + daccessamt;
				System.out.println("There are now "+ (daccessamt) + " permits in the inventory.");
				System.out.println("Would you like to continue?");
				System.out.println("1. Yes");
				System.out.println("2. No");
				
				int choice1 = scanner.nextInt();
				
				if (choice1 == 1) {
					inventoryactions();
				}
				else if (choice1 == 2) {
					main(null);
				}
			}
			else if (productselection == 2) {
				System.out.println("How many photo permits would you like to add?");
				int amountadded2 = scanner.nextInt();
				paccessamt = amountadded2 + paccessamt;
				System.out.println("There are now "+ (paccessamt) + " permits in the inventory.");
				System.out.println("Would you like to continue?");
				System.out.println("1. Yes");
				System.out.println("2. No");
				
				int choice1 = scanner.nextInt();
				
				if (choice1 == 1) {
					inventoryactions();
				}
				else if (choice1 == 2) {
					main(null);
				}
			}
			else if (productselection == 3) {
				System.out.println("How many discovery packages would you like to add?");
				int amountadded3 = scanner.nextInt();
				astinfoamt = amountadded3 + astinfoamt;
				System.out.println("There are now "+ (astinfoamt) + " discovery packages in the inventory.");
				System.out.println("Would you like to continue?");
				System.out.println("1. Yes");
				System.out.println("2. No");
				
				int choice1 = scanner.nextInt();
				
				if (choice1 == 1) {
					inventoryactions();
				}
				else if (choice1 == 2) {
					main(null);
				}
			}
			else if (productselection == 4) {
				System.out.println("How many asteroid information packages would you like to add?");
				int amountadded4 = scanner.nextInt();
				NEADamt = amountadded4 + NEADamt;
				System.out.println("There are now "+ (NEADamt) + " NEAD packages in the inventory.");
				System.out.println("Would you like to continue?");
				System.out.println("1. Yes");
				System.out.println("2. No");
				
				int choice1 = scanner.nextInt();
				
				if (choice1 == 1) {
					inventoryactions();
				}
				else if (choice1 == 2) {
					main(null);
				}
			}
		}
		else if (selectiontwo == 2) {
			System.out.println("These are the items currently in your inventory:");
			System.out.println(daccessamt + " database access permits");
			System.out.println(paccessamt + " photo permits");
			System.out.println(astinfoamt + " discovery packages");
			System.out.println(NEADamt + " NEADs");
			
			System.out.println("Would you like to return to the main menu or the inventory menu?");
			System.out.println("1. Main Menu");
			System.out.println("2. Inventory Menu");
			
			int choiceagain = scanner.nextInt();
			
			if (choiceagain == 1) {
				main(null);
			}
			else if (choiceagain == 2) {
				inventoryactions();
			}
		}
		else if (selectiontwo == 3) {
			main(null);
		}
		}
	 
	 static void salesactions() {
		 System.out.println("What would you like to do?");
		 System.out.println("1. View Products");
		 System.out.println("2. Purchase Products");
		 System.out.println("3. Exit to Main Menu");
		 
		 int actionselection =  scanner.nextInt();
		 
		 if (actionselection == 1) {
			System.out.println("These are the items you can purchase:");
			System.out.println("/nDatabase access permits - $200 per month");
			System.out.println("Photo access permits (recommended for scientists and civilians) - $20 a month");
			System.out.println("Information on resource rich asteroids  (recommended for companies) - $100 per information package");
			System.out.println("Near Earth Asteroid discoveries (recommended for scientists) - $50 per each asteroid");
			salesactions();
		 }
		 else if (actionselection == 2) {
			System.out.println("Which product would you like to purchase?");
			System.out.println("Database access permits - $200 per month");
			System.out.println("Photo access permits (recommended for scientists and civilians) - $20 a month");
			System.out.println("Information on resource rich asteroids  (recommended for companies) - $100 per information package");
			System.out.println("Near Earth Asteroid discoveries (recommended for scientists) - $50 per each asteroid");
			
			int itempurchase = scanner.nextInt();
			
			if (itempurchase == 1) {
				System.out.println("How many database access permits would you like to purchase?");
				int amountadded1 = scanner.nextInt();
				daccessamt = daccessamt - amountadded1;
				System.out.println("There are now "+ (daccessamt) + " permits left in the inventory.");
				System.out.println("Would you like to continue or return to the main menu?");
				System.out.println("1. Continue");
				System.out.println("2. Main Menu");
				
				int choice1 = scanner.nextInt();
				
				if (choice1 == 1) {
					salesactions();
				}
				else if (choice1 == 2) {
					main(null);
				}
			}
		    else if (itempurchase == 2) {
		    	System.out.println("How many photo permits would you like to purchase?");
				int amountadded2 = scanner.nextInt();
				paccessamt = paccessamt - amountadded2;
				System.out.println("There are now "+ (paccessamt) + " permits in the inventory.");
				System.out.println("Would you like to continue or return to the main menu?");
				System.out.println("1. Continue");
				System.out.println("2. Main Menu");
				
				int choice1 = scanner.nextInt();
				
				if (choice1 == 1) {
					salesactions();
				}
				else if (choice1 == 2) {
					main(null);
				}
			}
		    else if (itempurchase == 3) {
		    	System.out.println("How many discovery packages would you like to purchase?");
				int amountadded3 = scanner.nextInt();
				astinfoamt = astinfoamt - amountadded3;
				System.out.println("There are now "+ (astinfoamt) + " permits in the inventory.");
				System.out.println("Would you like to continue or return to the main menu?");
				System.out.println("1. Continue");
				System.out.println("2. Main Menu");
				
				int choice1 = scanner.nextInt();
				
				if (choice1 == 1) {
					salesactions();
				}
				else if (choice1 == 2) {
					main(null);
				}
			}
		    else if (itempurchase == 4) {
		    	System.out.println("How many NEAD packages would you like to purchase?");
				int amountadded4 = scanner.nextInt();
				NEADamt = NEADamt - amountadded4;
				System.out.println("There are now "+ (NEADamt) + " permits in the inventory.");
				System.out.println("Would you like to continue or return to the main menu?");
				System.out.println("1. Continue");
				System.out.println("2. Main Menu");
				
				int choice1 = scanner.nextInt();
				
				if (choice1 == 1) {
					salesactions();
				}
				else if (choice1 == 2) {
					main(null);
				}
			}
		 }
		 else if (actionselection == 3) {
			 main(null);
		 }
 }
}

